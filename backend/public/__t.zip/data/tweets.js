window.YTD.tweets.part0 = [
  {
    "tweet": {
      "id_str": "1001",
      "full_text": "Russian strike on a residential block in Bakhmut this morning. Geolocated to 48.5956, 37.9999. #Ukraine",
      "created_at": "Mon Mar 03 08:14:00 +0000 2025",
      "extended_entities": {
        "media": [
          {
            "type": "photo",
            "media_url_https": "https://pbs.twimg.com/media/bakhmut.jpg"
          }
        ]
      }
    }
  },
  {
    "tweet": {
      "id_str": "1002",
      "full_text": "Overnight footage from the Avdiivka coke plant area. Heavy shelling, secondary explosions. Working on the exact spot, thread below.",
      "created_at": "Tue Mar 11 21:40:00 +0000 2025",
      "extended_entities": {
        "media": [
          {
            "type": "photo",
            "media_url_https": "https://pbs.twimg.com/media/avdiivka.jpg"
          }
        ]
      }
    }
  },
  {
    "tweet": {
      "id_str": "1003",
      "full_text": "Geolocated to 48.1003, 37.7560 \u2014 the coke plant's northern edge, matching the treeline and the rail spur.",
      "created_at": "Tue Mar 11 22:05:00 +0000 2025",
      "in_reply_to_status_id_str": "1002"
    }
  },
  {
    "tweet": {
      "id_str": "1004",
      "full_text": "Damage near the Kherson river port. Coordinates 46.6354, 32.6169.",
      "created_at": "Sat Mar 22 16:02:00 +0000 2025",
      "extended_entities": {
        "media": [
          {
            "type": "photo",
            "media_url_https": "https://pbs.twimg.com/media/kherson.jpg"
          }
        ]
      }
    }
  },
  {
    "tweet": {
      "id_str": "1005",
      "full_text": "Some commentary on the week, no location in this one. More analysis soon.",
      "created_at": "Sun Mar 23 10:00:00 +0000 2025"
    }
  },
  {
    "tweet": {
      "id_str": "1006",
      "full_text": "Fresh crater near Kupiansk: 49.7106, 37.6156. No usable footage yet.",
      "created_at": "Wed Apr 02 12:30:00 +0000 2025"
    }
  },
  {
    "tweet": {
      "id_str": "1007",
      "full_text": "Appreciate everyone sharing context on the last thread.",
      "created_at": "Wed Apr 02 18:45:00 +0000 2025",
      "in_reply_to_status_id_str": "1003"
    }
  }
]